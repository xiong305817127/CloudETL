/*
 *                广东粤数大数据有限公司
 *
 * 功能描述：实现wordcount功能。
 * 设计目标：为方便用户快捷上手使用，提供iDatrix数据平台下 任务管理功能中hadoopJava任务类型模板实例。
 * 设计说明：任务继承于AbstractHadoopJob，用户使用时需要注意几点问题
 * 		 1. 运行入口为run()函数。
 * 		 2. 配置获取Job参数时必须使用： JobConf jobconf = getJobConf();
 * 		 3. run函数末尾必须需运行：        super.run(); 
 * 		 4. 函数参数input.path/output.path为页面配置内容。
 * 
 * 创建时间：2017-08-18 by Robin
 * 
 */

package com.ys.hadoop.template;

import java.io.IOException;
import java.util.Iterator;
import java.util.StringTokenizer;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;
import org.apache.log4j.Logger;

import azkaban.jobtype.javautils.AbstractHadoopJob;
import azkaban.utils.Props;

public class WordCount extends AbstractHadoopJob {
   
	private final String inputPath;
	private final String outputPath;
	private boolean forceOutputOverrite;

	public WordCount(String name, Props props) {
		super(name, props);
		this.inputPath = props.getString("input.path");
		this.outputPath = props.getString("output.path");
		this.forceOutputOverrite =
				props.getBoolean("force.output.overwrite", false);
	}
	
	public static class Map extends MapReduceBase implements
    Mapper<LongWritable, Text, Text, IntWritable> {
		static enum Counters {
			INPUT_WORDS
		};
	
		private final static IntWritable one = new IntWritable(1);
		private Text word = new Text();
		private long numRecords = 0;

		public void map(LongWritable key, Text value,
			OutputCollector<Text, IntWritable> output, Reporter reporter)
					throws IOException {
		    String line = value.toString();
		    StringTokenizer tokenizer = new StringTokenizer(line);
		    while (tokenizer.hasMoreTokens()) {
		      word.set(tokenizer.nextToken());
		      output.collect(word, one);
		      reporter.incrCounter(Counters.INPUT_WORDS, 1);
		    }
	
		    if ((++numRecords % 100) == 0) {
		      reporter.setStatus("Finished processing " + numRecords + " records "
		          + "from the input file");
		    }
		}
	}

	public static class Reduce extends MapReduceBase implements
    	Reducer<Text, IntWritable, Text, IntWritable> {
		
		public void reduce(Text key, Iterator<IntWritable> values,
				OutputCollector<Text, IntWritable> output, Reporter reporter)
					throws IOException {
				int sum = 0;
				while (values.hasNext()) {
					sum += values.next().get();
				}
				output.collect(key, new IntWritable(sum));
			}
		}

	public void run() throws Exception {
		
		//获取jobconf文件，该文件必须通过getJobConf()函数!
		JobConf jobconf = getJobConf();
		jobconf.setJarByClass(WordCount.class);

		jobconf.setOutputKeyClass(Text.class);
		jobconf.setOutputValueClass(IntWritable.class);

	    jobconf.setMapperClass(Map.class);
	    jobconf.setReducerClass(Reduce.class);
	
	    jobconf.setInputFormat(TextInputFormat.class);
	    jobconf.setOutputFormat(TextOutputFormat.class);
	
	    //配置输入和输出路径
	    FileInputFormat.addInputPath(jobconf, new Path(inputPath));
	    FileOutputFormat.setOutputPath(jobconf, new Path(outputPath));
	
	    if (forceOutputOverrite) {
	      FileSystem fs =
	          FileOutputFormat.getOutputPath(jobconf).getFileSystem(jobconf);
	      fs.delete(FileOutputFormat.getOutputPath(jobconf), true);
	    }
	    //该函数必须在最后被调用！
	    super.run();
	}
}
